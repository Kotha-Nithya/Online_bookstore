package com.store.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.store.model.Employee;
import com.store.model.Login;
import com.store.repository.EmployeeRepository;

@RequestMapping("/emp")
@Controller
public class EmployeeController {

	@Autowired
	EmployeeRepository repo;

	@RequestMapping()
	public String login(Model model) {
		return "emp_login";
	}

	@RequestMapping("/home")
	public String staffhome() {
		return "emp_home";
	}
	@RequestMapping("/logout")
	public String logout(Model model, HttpServletRequest req) {
		req.getSession().invalidate();
		return "logout";
	}

	@PostMapping("/login")
	public String show(Login login, Model model, HttpServletRequest request) {
		if (login.getEmail().equals("admin") && login.getPassword().equals("admin")) {
			request.getSession().setAttribute("id", "1001");
			request.getSession().setAttribute("userid", "EMPL000001");
			request.getSession().setAttribute("usertype", "staff");
			request.getSession().setAttribute("name", "Admin");
			return "emp_home";

		}
		Optional<Employee> obj = repo.findByEmailAndPassword(login.getEmail(), login.getPassword());

		if (obj.isPresent()) {
			model.addAttribute("name", obj.get().getFirstName());
			request.getSession().setAttribute("id", obj.get().getId());
			request.getSession().setAttribute("userid", obj.get().getEmpId());
			request.getSession().setAttribute("usertype", "staff");
			request.getSession().setAttribute("name", obj.get().getFirstName());
			return "emp_home";
		} else {
			model.addAttribute("msg", "Invalid Login Credentials");
			return "emp_login";
		}
	}

	@RequestMapping("/list")
	public String home(Model model, HttpServletRequest request) {
		model.addAttribute("datalist", repo.findAll());
		return "emp";
	}

	@RequestMapping("/create")
	public String create(Model model, HttpServletRequest request) {
		return "emp_create";
	}

	@RequestMapping("/save")
	public String save(Employee obj, Model model) {
		Optional<Employee> exobj = repo.findByEmail(obj.getEmail());

		if (!exobj.isPresent()) {
			Optional<Employee> idobj = repo.findTopByOrderByIdDesc();
			String id = null;
			if (idobj.isPresent()) {
				int idnum = Integer.parseInt(idobj.get().getEmpId().substring(5));
				idnum++;
				id = "EMPL0" + idnum;
			} else {
				id = "EMPL021301";
			}
			obj.setEmpId(id);
			repo.save(obj);
			return "redirect:/emp/list";
		}
		else
		{
			String msg = "Employee with "+obj.getEmail()+" already registered";
			model.addAttribute("msg",msg);
			model.addAttribute("datalist", repo.findAll());
			return "emp";

		}
	}

	@RequestMapping("/show/{id}")
	public String show(@PathVariable String id, Model model, HttpServletRequest request) {
		model.addAttribute("obj", repo.findById(id).get());
		return "emp_show";
	}

	@RequestMapping("/delete")
	public String delete(@RequestParam String id) {
		Optional<Employee> obj = repo.findById(id);
		repo.delete(obj.get());

		return "redirect:/emp/list";
	}

	@RequestMapping("/edit/{id}")
	public String edit(@PathVariable String id, Model model) {
		model.addAttribute("obj", repo.findById(id).get());
		return "emp_edit";
	}

	@RequestMapping("/update")
	public String update(Employee obj) {
		repo.save(obj);
		return "redirect:/emp/show/" + obj.getId();
	}
}
