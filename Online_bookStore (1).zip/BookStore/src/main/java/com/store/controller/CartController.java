package com.store.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.store.model.Cart;
import com.store.model.Order;
import com.store.model.OrderItem;
import com.store.repository.BookRepository;
import com.store.repository.CartRepository;
import com.store.repository.OrderRepository;

@RequestMapping("/cart")
@Controller
public class CartController {

	@Autowired
	CartRepository cartRepo;

	@Autowired
	BookRepository repo;

	@Autowired
	OrderRepository ordRepo;

	@RequestMapping("/add")
	public String addToCart(OrderItem obj, HttpServletRequest req, Model model) throws IOException {

		Optional<Cart> optCart = cartRepo.findByCustId(req.getSession().getAttribute("userid").toString());
		Cart cart;

		if (optCart.isPresent()) {
			cart = optCart.get();
			List<OrderItem> orders;
			
			if(cart.getOrderItems() != null)
				orders = cart.getOrderItems();
			else
				orders = new ArrayList<>();
			
			boolean flag = true;
			if (orders != null) {
				for (OrderItem item : orders) {
					if (item.getBookId().equals(obj.getBookId())) {
						double unitPrice = item.getPrice() / item.getQty();

						item.setQty(item.getQty() + 1);
						item.setPrice(item.getPrice() + unitPrice);
						flag = false;
						break;
					}
				}
			}

			if (flag) {
				obj.setQty(1);
				orders.add(obj);
			}
			cart.setOrderItems(orders);
			System.out.println("Cart : " + cart);
			cartRepo.save(cart);
		} else {
			cart = new Cart();
			Optional<Cart> idobj = cartRepo.findTopByOrderByIdDesc();
			String id = null;
			if (idobj.isPresent()) {
				int idnum = Integer.parseInt(idobj.get().getCartId().substring(5));
				idnum++;
				id = "CART7" + idnum;
			} else {
				id = "CART731842";
			}
			cart.setCartId(id);
			cart.setCustId(req.getSession().getAttribute("userid").toString());
			List<OrderItem> orders = new ArrayList<>();
			obj.setQty(1);
			orders.add(obj);
			cart.setOrderItems(orders);
			System.out.println("Cart : " + cart);

			cartRepo.save(cart);

		}

		return "redirect:/customer/home";
	}

	@RequestMapping("/incr")
	public String incrToCart(OrderItem obj, HttpServletRequest req, Model model) throws IOException {

		Cart cart = cartRepo.findByCustId(req.getSession().getAttribute("userid").toString()).get();

		List<OrderItem> orders = cart.getOrderItems();
		for (OrderItem item : orders) {
			if (item.getBookId().equals(obj.getBookId())) {
				double unitPrice = item.getPrice() / item.getQty();
				item.setQty(item.getQty() + 1);
				item.setPrice(item.getPrice() + unitPrice);
				break;
			}
		}

		System.out.println("Cart : " + cart);
		cartRepo.save(cart);

		return "redirect:/cart/show";
	}

	@RequestMapping("/decr")
	public String decrToCart(OrderItem obj, HttpServletRequest req, Model model) throws IOException {

		Cart cart = cartRepo.findByCustId(req.getSession().getAttribute("userid").toString()).get();

		List<OrderItem> orders = cart.getOrderItems();
		for (OrderItem item : orders) {
			if (item.getBookId().equals(obj.getBookId())) {
				if (item.getQty() > 1) {
					double unitPrice = item.getPrice() / item.getQty();
					item.setQty(item.getQty() - 1);
					item.setPrice(item.getPrice() - unitPrice);
					break;
				} else {
					orders.remove(item);
					break;
				}
			}
		}

		System.out.println("Cart : " + cart);
		cartRepo.save(cart);

		return "redirect:/cart/show";
	}

	@RequestMapping("/show")
	public String showMyCart(Model model, HttpServletRequest request) {
		model.addAttribute("datalist",
				cartRepo.findByCustId(request.getSession().getAttribute("userid").toString()).get().getOrderItems());
		return "cart_items";
	}

	@RequestMapping("/mylist")
	public String myOrderList(Model model, HttpServletRequest request) {
		model.addAttribute("datalist",
				ordRepo.findByCustId(request.getSession().getAttribute("userid").toString()).get());
		return "myorder";
	}

	@RequestMapping("/list")
	public String orderList(Model model) {
		model.addAttribute("datalist", ordRepo.findAll());
		return "order";
	}

	@RequestMapping("/remove")
	public String removeItem(OrderItem obj, HttpServletRequest req, Model model) throws IOException {

		@SuppressWarnings("unchecked")
		List<OrderItem> orders = (List<OrderItem>) req.getSession().getAttribute("orders");
		if (orders != null) {
			for (OrderItem item : orders) {
				if (item.getBookId().equals(obj.getBookId())) {
					item.setQty(item.getQty() - 1);
					item.setPrice(item.getPrice() - obj.getPrice());
					System.out.println(item.getName() + " : " + item.getQty());
					if (item.getQty() == 0) {

						orders.remove(item);
					}
					break;
				}
			}

			req.getSession().setAttribute("orders", orders);

		}
		if (req.getSession().getAttribute(obj.getBookId()) != null) {
			int q = Integer.parseInt(req.getSession().getAttribute(obj.getBookId()).toString());
			if (q > 0)
				q--;
			req.getSession().setAttribute(obj.getBookId(), q);
		}

		model.addAttribute("datalist", repo.findAll());
		return "order_items";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/save")
	public String save(HttpServletRequest req) throws IOException {

		Optional<Order> idobj = ordRepo.findTopByOrderByIdDesc();
		String id = null;
		if (idobj.isPresent()) {
			int idnum = Integer.parseInt(idobj.get().getOrderId().substring(5));
			idnum++;
			id = "ORD47" + idnum;
		} else {
			id = "ORD4731842";
		}

		Order order = new Order();
		order.setCustId(req.getSession().getAttribute("userid").toString());
		order.setStaffId("");
		order.setOrderId(id);
		order.setOrderItems((List<OrderItem>) req.getSession().getAttribute("orders"));
		List<OrderItem> items = (List<OrderItem>) req.getSession().getAttribute("orders");

		double amount = 0;
		for (OrderItem item : items) {
			amount += item.getPrice();
		}
		order.setAmount(amount);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		order.setOrderedDate(dtf.format(now));
		order.setDeliveryStatus("UnDelivered");
		Order savedOrder = ordRepo.save(order);
		req.getSession().removeAttribute("orders");

		String sid = req.getSession().getAttribute("id").toString();
		String userid = req.getSession().getAttribute("userid").toString();
		String usertype = req.getSession().getAttribute("usertype").toString();
		String name = req.getSession().getAttribute("name").toString();

		req.getSession().invalidate();

		req.getSession().setAttribute("id", sid);
		req.getSession().setAttribute("userid", userid);
		req.getSession().setAttribute("usertype", usertype);
		req.getSession().setAttribute("name", name);

		return "redirect:/order/placed/" + savedOrder.getId();
	}

	@RequestMapping("/placed/{id}")
	public String show(@PathVariable String id, Model model, HttpServletRequest req) {

		Order order = ordRepo.findById(id).get();
		model.addAttribute("obj", order);
		if (req.getSession().getAttribute("usertype").equals("customer"))
			return "order_details_cust";
		else
			return "order_details";
	}

	@RequestMapping("/delivery/update/{id}")
	public String deliveryUpdate(@PathVariable String id, Model model, HttpServletRequest req) {

		Order order = ordRepo.findById(id).get();
		order.setDeliveryStatus("Delivered");
		order.setStaffId(req.getSession().getAttribute("userid").toString());

		ordRepo.save(order);
		return "redirect:/order/list/";

	}

	@RequestMapping("/delivery/cancel/{id}")
	public String deliveryCancel(@PathVariable String id, Model model, HttpServletRequest req) {

		Order order = ordRepo.findById(id).get();
		order.setDeliveryStatus("Cancelled");
		ordRepo.save(order);
		return "redirect:/order/list/";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam String id) {
		Order obj = ordRepo.findById(id).get();
		ordRepo.delete(obj);

		return "redirect:/order/mylist";
	}

}
