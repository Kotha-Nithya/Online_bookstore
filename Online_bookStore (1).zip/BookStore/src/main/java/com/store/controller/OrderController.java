package com.store.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.store.model.Book;
import com.store.model.Cart;
import com.store.model.Order;
import com.store.model.OrderItem;
import com.store.model.Payment;
import com.store.repository.BookRepository;
import com.store.repository.CartRepository;
import com.store.repository.OrderRepository;
import com.store.repository.PaymentRepository;

@RequestMapping("/order")
@Controller
public class OrderController {

	@Autowired
	BookRepository repo;

	@Autowired
	CartRepository cartRepo;

	@Autowired
	PaymentRepository payRepo;

	@Autowired
	OrderRepository ordRepo;

	@RequestMapping("/mylist")
	public String myOrderList(Model model, HttpServletRequest request) {
		model.addAttribute("datalist",
				ordRepo.findByCustId(request.getSession().getAttribute("userid").toString()).get());
		return "myorder";
	}

	@RequestMapping("/list")
	public String orderList(Model model) {
		model.addAttribute("datalist", ordRepo.findAll());
		return "order";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/save")
	public String save(Payment payment, HttpServletRequest req) throws IOException {

		Optional<Order> idobj = ordRepo.findTopByOrderByIdDesc();
		String id = null;
		if (idobj.isPresent()) {
			int idnum = Integer.parseInt(idobj.get().getOrderId().substring(5));
			idnum++;
			id = "ORD47" + idnum;
		} else {
			id = "ORD4731842";
		}

		Order order = new Order();
		order.setCustId(req.getSession().getAttribute("userid").toString());
		order.setOrderId(id);

		payment.setCustId(req.getSession().getAttribute("userid").toString());
		payment.setOrderId(id);

		Cart cart = cartRepo.findByCustId(req.getSession().getAttribute("userid").toString()).get();

		List<OrderItem> items = cart.getOrderItems();
		order.setOrderItems(items);

		double amount = 0;
		for (OrderItem item : items) {

			Book book = repo.findByBookId(item.getBookId()).get();
			book.setCopiesAvl(book.getCopiesAvl() - item.getQty());
			book.setCopiesSold(book.getCopiesSold() + item.getQty());
			repo.save(book);

			amount += item.getPrice();
		}
		order.setAmount(amount);
		payment.setAmount(amount);

		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		order.setOrderedDate(dtf.format(now));
		order.setDeliveryStatus("UnDelivered");
		Order savedOrder = ordRepo.save(order);

		payment.setPaymentDate(dtf.format(now));
		payment.setPaymentStatus("Paid");

		cart.setOrderItems(null);
		cartRepo.save(cart);

		payRepo.save(payment);
		return "redirect:/order/placed/" + savedOrder.getId();
	}

	@RequestMapping("/placed/{id}")
	public String show(@PathVariable String id, Model model, HttpServletRequest req) {

		Order order = ordRepo.findById(id).get();
		model.addAttribute("obj", order);
		if (req.getSession().getAttribute("usertype").equals("customer"))
			return "order_details_cust";
		else
			return "order_details";
	}

	@RequestMapping("/delivery/update/{id}")
	public String deliveryUpdate(@PathVariable String id, Model model, HttpServletRequest req) {

		Order order = ordRepo.findById(id).get();
		order.setDeliveryStatus("Delivered");
		order.setStaffId(req.getSession().getAttribute("userid").toString());

		ordRepo.save(order);
		return "redirect:/order/list/";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam String id) {
		Order obj = ordRepo.findById(id).get();
		List<OrderItem> items = obj.getOrderItems();
		ordRepo.delete(obj);
		for (OrderItem item : items) {

			Book book = repo.findByBookId(item.getBookId()).get();
			book.setCopiesAvl(book.getCopiesAvl() + item.getQty());
			book.setCopiesSold(book.getCopiesSold() - item.getQty());
			repo.save(book);

			// amount += item.getPrice();
		}

		return "redirect:/order/mylist";
	}

}
