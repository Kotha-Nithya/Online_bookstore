package com.store.controller;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.store.model.Book;
import com.store.repository.BookRepository;
import com.store.service.FileUploadUtil;

@RequestMapping("/book")
@Controller
public class BookController {

	@Autowired
	BookRepository repo;
	
	
	@RequestMapping("/list")
    public String home(Model model) {
        model.addAttribute("datalist", repo.findAll());
        return "book";
    }
	
	@RequestMapping("/create")
	public String create(Model model) {
		return "book_create";
	}
	
	@RequestMapping("/save")
	public String save(Book obj, HttpServletRequest req, @RequestParam("image") MultipartFile multipartFile) throws IOException{
		Optional<Book> idobj = repo.findTopByOrderByIdDesc();
		String id = null;
		if(idobj.isPresent())
		{
			int idnum = Integer.parseInt(idobj.get().getBookId().substring(5));
			idnum++;
			id = "BOOK3"+idnum;
		}
		else
		{
			id = "BOOK362353";
		}
		
		String imgUrl = id+multipartFile.getOriginalFilename();
		obj.setBookId(id);
		
		obj.setImgUrl(imgUrl);
		obj.setEmpId(req.getSession().getAttribute("userid").toString());
		repo.save(obj);		
		
		String uploadDir = "uploads";
        
        FileUploadUtil.saveFile(uploadDir, imgUrl, multipartFile);
		return "redirect:/book/list";
	}
	

	
	@RequestMapping("/show/{id}")
	public String show(@PathVariable String id, Model model) {
		model.addAttribute("obj",repo.findById(id).get());
		return "book_show";
	}
	
	 @RequestMapping("/delete")
	    public String delete(@RequestParam String id) {
	        Optional<Book> obj = repo.findById(id);

	        repo.delete(obj.get());
	        return "redirect:/book/list";
	    }
	    
	    @RequestMapping("/edit/{id}")
	    public String edit(@PathVariable String id, Model model) {
	        model.addAttribute("obj", repo.findById(id).get());

	        return "book_edit";
	    }
	    
	    @RequestMapping("/update")
	    public String update(Book obj) {
		    repo.save(obj);

	        return "redirect:/book/show/" + obj.getId();
	    }
	    

}
