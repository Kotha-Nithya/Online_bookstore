package com.store.model;

public class OrderItem {
	String bookId;
	String name;
	String imgUrl;
	int qty;
	double price;

	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderItem(String bookId, String name, String imgUrl, int qty, double price) {
		super();
		this.bookId = bookId;
		this.name = name;
		this.imgUrl = imgUrl;
		this.qty = qty;
		this.price = price;
	}

	@Override
	public String toString() {
		return "OrderItem [bookId=" + bookId + ", name=" + name + ", imgUrl=" + imgUrl + ", qty=" + qty + ", price="
				+ price + "]";
	}

	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	

}
