package com.store.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "cart")
public class Cart {
	
	@Id
	String id;
	String cartId;
	String custId;
	List<OrderItem> orderItems;
	

	
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}



	public Cart(String id, String cartId, String custId, List<OrderItem> orderItems) {
		super();
		this.id = id;
		this.cartId = cartId;
		this.custId = custId;
		this.orderItems = orderItems;
	}



	@Override
	public String toString() {
		return "Cart [id=" + id + ", cartId=" + cartId + ", custId=" + custId + ", orderItems=" + orderItems + "]";
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getCartId() {
		return cartId;
	}



	public void setCartId(String cartId) {
		this.cartId = cartId;
	}



	public String getCustId() {
		return custId;
	}



	public void setCustId(String custId) {
		this.custId = custId;
	}



	public List<OrderItem> getOrderItems() {
		return orderItems;
	}



	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

}
