package com.store.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "book")
public class Book {
	
	@Id
	String id;
	String bookId;
	String empId;
	String name;
	String author;
	double price;
	String description;
	int copiesAvl;
	int copiesSold;
	String imgUrl;

	
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Book(String id, String bookId, String empId, String name, String author, double price, String description,
			int copiesAvl, int copiesSold, String imgUrl) {
		super();
		this.id = id;
		this.bookId = bookId;
		this.empId = empId;
		this.name = name;
		this.author = author;
		this.price = price;
		this.description = description;
		this.copiesAvl = copiesAvl;
		this.copiesSold = copiesSold;
		this.imgUrl = imgUrl;
	}


	@Override
	public String toString() {
		return "Book [id=" + id + ", bookId=" + bookId + ", empId=" + empId + ", name=" + name + ", author=" + author
				+ ", price=" + price + ", description=" + description + ", copiesAvl=" + copiesAvl + ", copiesSold="
				+ copiesSold + ", imgUrl=" + imgUrl + "]";
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getBookId() {
		return bookId;
	}


	public void setBookId(String bookId) {
		this.bookId = bookId;
	}


	public String getEmpId() {
		return empId;
	}


	public void setEmpId(String empId) {
		this.empId = empId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAuthor() {
		return author;
	}


	public void setAuthor(String author) {
		this.author = author;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public int getCopiesAvl() {
		return copiesAvl;
	}


	public void setCopiesAvl(int copiesAvl) {
		this.copiesAvl = copiesAvl;
	}


	public int getCopiesSold() {
		return copiesSold;
	}


	public void setCopiesSold(int copiesSold) {
		this.copiesSold = copiesSold;
	}


	public String getImgUrl() {
		return imgUrl;
	}


	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}


	
}
