package com.store.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "payment")
public class Payment {
	
	@Id
	String id;
	String orderId;
	String custId;
	String paymentType;
	String paymentDate;
	double amount;
	String paymentStatus;

	
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Payment(String id, String orderId, String custId, String paymentType, String paymentDate, double amount,
			String paymentStatus) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.custId = custId;
		this.paymentType = paymentType;
		this.paymentDate = paymentDate;
		this.amount = amount;
		this.paymentStatus = paymentStatus;
	}


	@Override
	public String toString() {
		return "Payment [id=" + id + ", orderId=" + orderId + ", custId=" + custId + ", paymentType=" + paymentType
				+ ", paymentDate=" + paymentDate + ", amount=" + amount + ", paymentStatus=" + paymentStatus + "]";
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getCustId() {
		return custId;
	}


	public void setCustId(String custId) {
		this.custId = custId;
	}


	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	public String getPaymentDate() {
		return paymentDate;
	}


	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public String getPaymentStatus() {
		return paymentStatus;
	}


	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}


}
