package com.store.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "order")
public class Order {
	
	@Id
	String id;
	String orderId;
	String custId;
	String staffId;
	List<OrderItem> orderItems;
	String orderedDate;
	double amount;
	String deliveryStatus;
	String deliveredTime;
	String deliveredBy;

	
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "Order [id=" + id + ", orderId=" + orderId + ", staffId=" + staffId + ", custId=" + custId + ", orderItems=" + orderItems
				+ ", orderedDate=" + orderedDate + ", amount=" + amount 
				+ ", deliveryStatus=" + deliveryStatus + ", deliveredTime=" + deliveredTime + ", deliveredBy="
				+ deliveredBy + "]";
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getCustId() {
		return custId;
	}


	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public String getStaffId() {
		return staffId;
	}


	public void setCustId(String custId) {
		this.custId = custId;
	}


	public List<OrderItem> getOrderItems() {
		return orderItems;
	}


	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}


	public String getOrderedDate() {
		return orderedDate;
	}


	public void setOrderedDate(String orderedDate) {
		this.orderedDate = orderedDate;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public String getDeliveryStatus() {
		return deliveryStatus;
	}


	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}


	public String getDeliveredTime() {
		return deliveredTime;
	}


	public void setDeliveredTime(String deliveredTime) {
		this.deliveredTime = deliveredTime;
	}


	public String getDeliveredBy() {
		return deliveredBy;
	}


	public void setDeliveredBy(String deliveredBy) {
		this.deliveredBy = deliveredBy;
	}


	public Order(String id, String orderId, String staffId, String custId, List<OrderItem> orderItems, String orderedDate,
			double amount,  String deliveryStatus, String deliveredTime, String deliveredBy) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.custId = custId;
		this.staffId = staffId;
		this.orderItems = orderItems;
		this.orderedDate = orderedDate;
		this.amount = amount;
		this.deliveryStatus = deliveryStatus;
		this.deliveredTime = deliveredTime;
		this.deliveredBy = deliveredBy;
	}


	
}
