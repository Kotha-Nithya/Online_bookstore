package com.store.repository;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.store.model.Book;

@Repository
public interface BookRepository extends CrudRepository<Book, String>{

	Optional<Book> findTopByOrderByIdDesc();

	Optional<Book> findByBookId(String bookId);


}
