package com.store.repository;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.store.model.Employee;

@Repository
public interface EmployeeRepository extends CrudRepository<Employee, String>{

	Optional<Employee> findTopByOrderByIdDesc();

	Optional<Employee> findByEmailAndPassword(String email, String password);

	Optional<Employee> findByEmail(String email);


}
